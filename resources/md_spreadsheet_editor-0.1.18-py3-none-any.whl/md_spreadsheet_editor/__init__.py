"""
Markdown Spreadsheet Editor
Core logic for VS Code extension.
"""

__version__ = "0.1.0"
