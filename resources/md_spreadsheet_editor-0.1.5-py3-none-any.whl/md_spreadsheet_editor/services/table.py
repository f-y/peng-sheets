from dataclasses import replace

from md_spreadsheet_parser import Table

from .sheet import apply_sheet_update
from .workbook import update_workbook


def add_table(context, sheet_idx, column_names=None):
    if column_names is None:
        column_names = ["Column 1", "Column 2", "Column 3"]

    def sheet_transform(sheet):
        new_tables = list(sheet.tables)
        new_table = Table(
            name=f"New Table {len(new_tables) + 1}",
            description="",
            headers=column_names,
            rows=[["" for _ in column_names]],
            metadata={},
        )
        new_tables.append(new_table)
        return replace(sheet, tables=new_tables)

    return apply_sheet_update(context, sheet_idx, sheet_transform)


def delete_table(context, sheet_idx, table_idx):
    def sheet_transform(sheet):
        new_tables = list(sheet.tables)
        if table_idx < 0 or table_idx >= len(new_tables):
            raise IndexError("Invalid table index")

        del new_tables[table_idx]
        return replace(sheet, tables=new_tables)

    return apply_sheet_update(context, sheet_idx, sheet_transform)


def rename_table(context, sheet_idx, table_idx, new_name):
    def sheet_transform(sheet):
        new_tables = list(sheet.tables)
        if table_idx < 0 or table_idx >= len(new_tables):
            raise IndexError("Invalid table index")

        target_table = new_tables[table_idx]
        new_table = replace(target_table, name=new_name)
        new_tables[table_idx] = new_table
        return replace(sheet, tables=new_tables)

    return apply_sheet_update(context, sheet_idx, sheet_transform)
